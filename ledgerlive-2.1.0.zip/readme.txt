Sorry, this version of Ledger Live software is no longer supported.
Use the latest version of Ledger Live.